# Excluded timing pilot

This first attempt was stopped after its control measurements overlapped the tail
of the preflight worker. Its incomplete artifacts are preserved, but its timings
are excluded from every comparison. The verified preflight finished successfully.
The clean run is in `../cnf-cover-probe/`; no runtime sources changed between runs.
Bindings inside this incomplete pilot retain their originally requested output
paths and must not be interpreted as bindings to the clean run.
